#pragma once

namespace MotorGamePad
{
    void xyza_changed_event(int x, int y, int z, int a);
};