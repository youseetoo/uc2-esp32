#pragma once
struct WifiConfig
{
	char* mSsid;
    char* pw;
    bool ap;
};
