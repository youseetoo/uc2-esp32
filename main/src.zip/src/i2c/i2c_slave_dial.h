#pragma once

namespace i2c_slave_dial
{
    void setup();
} // namespace i2c_slave_dial
